﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    //uml creado
    public enum FrecuenciaVuelo
    {
        Lunes,
        Martes,
        Miercoles,
        Jueves,
        Viernes,
        Sabado,
        Domingo
    }
}
