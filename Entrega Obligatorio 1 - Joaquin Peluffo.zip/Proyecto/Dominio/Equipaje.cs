﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    //UML CREADO
    public enum Equipaje
    {
        LIGHT, 
        CABINA,
        BODEGA
    }
}
